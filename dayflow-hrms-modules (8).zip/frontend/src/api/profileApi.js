import { apiRequest } from './apiClient.js'

export function getOwnProfile() {
  return apiRequest('/profile/me')
}

export function updateOwnProfile(payload) {
  return apiRequest('/profile/me', { method: 'PUT', body: JSON.stringify(payload) })
}

export function getEmployeeProfile(employeeId) {
  return apiRequest(`/profile/${encodeURIComponent(employeeId)}`)
}

export function updateEmployeeProfileAsAdmin(employeeId, payload) {
  return apiRequest(`/profile/${encodeURIComponent(employeeId)}`, {
    method: 'PUT',
    body: JSON.stringify(payload)
  })
}
