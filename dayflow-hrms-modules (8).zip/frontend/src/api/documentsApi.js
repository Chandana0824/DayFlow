import { apiRequest } from './apiClient.js'

export function getMyDocuments() {
  return apiRequest('/documents/me')
}

export function getDocumentsForEmployee(employeeId) {
  return apiRequest(`/documents/${encodeURIComponent(employeeId)}`)
}

export function addDocument(employeeId, payload) {
  return apiRequest(`/documents/${encodeURIComponent(employeeId)}`, {
    method: 'POST',
    body: JSON.stringify(payload)
  })
}

export function deleteDocument(documentId) {
  return apiRequest(`/documents/${documentId}`, { method: 'DELETE' })
}
