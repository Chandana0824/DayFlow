import { apiRequest } from './apiClient.js'

export function getEmployeeDashboard() {
  return apiRequest('/dashboard/employee')
}

export function getAdminDashboard() {
  return apiRequest('/dashboard/admin')
}
