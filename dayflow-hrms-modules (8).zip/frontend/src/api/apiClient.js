// Shared authenticated fetch wrapper for dashboard/profile/attendance calls.
// Reads the JWT saved at sign-in (see pages/SignIn.jsx) and attaches it as
// a Bearer token, since these endpoints are protected by JwtAuthFilter on
// the backend (unlike /api/auth/** which is public).

export function getToken() {
  return localStorage.getItem('dayflow_token')
}

export function getRole() {
  return localStorage.getItem('dayflow_role')
}

export function getEmployeeId() {
  return localStorage.getItem('dayflow_employee_id')
}

export function isLoggedIn() {
  return Boolean(getToken())
}

export function logout() {
  localStorage.removeItem('dayflow_token')
  localStorage.removeItem('dayflow_role')
  localStorage.removeItem('dayflow_employee_id')
}

export async function apiRequest(path, options = {}) {
  const token = getToken()
  const res = await fetch(`/api${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {})
    }
  })

  if (res.status === 401 || res.status === 403) {
    logout()
    window.location.href = '/signin'
    throw new Error('Session expired. Please sign in again.')
  }

  const data = await res.json().catch(() => ({}))

  if (!res.ok) {
    const err = new Error(data?.message || 'Something went wrong. Please try again.')
    err.fieldErrors = data?.errors || null
    err.status = res.status
    throw err
  }

  return data
}
