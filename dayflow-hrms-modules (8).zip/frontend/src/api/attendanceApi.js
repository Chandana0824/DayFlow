import { apiRequest } from './apiClient.js'

export function checkIn() {
  return apiRequest('/attendance/check-in', { method: 'POST' })
}

export function checkOut() {
  return apiRequest('/attendance/check-out', { method: 'POST' })
}

export function getMyAttendance(from, to) {
  return apiRequest(`/attendance/me?from=${from}&to=${to}`)
}

export function getAllAttendance(from, to) {
  return apiRequest(`/attendance?from=${from}&to=${to}`)
}

export function getAttendanceForEmployee(employeeId, from, to) {
  return apiRequest(`/attendance/${encodeURIComponent(employeeId)}?from=${from}&to=${to}`)
}
