const LABELS = {
  PRESENT: 'Present',
  ABSENT: 'Absent',
  HALF_DAY: 'Half-day',
  LEAVE: 'Leave',
  NOT_MARKED: 'Not marked'
}

export default function StatusBadge({ status }) {
  const key = (status || 'NOT_MARKED').toUpperCase()
  const cls = `status-badge status-${key.toLowerCase()}`
  return <span className={cls}>{LABELS[key] || status}</span>
}
