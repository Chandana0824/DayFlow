import { Link, useLocation, useNavigate } from 'react-router-dom'
import { getRole, getEmployeeId, logout } from '../api/apiClient.js'

const EMPLOYEE_LINKS = [
  { to: '/dashboard', label: 'Dashboard' },
  { to: '/profile', label: 'Profile' },
  { to: '/attendance', label: 'Attendance' }
]

const ADMIN_LINKS = [
  { to: '/admin/dashboard', label: 'Dashboard' },
  { to: '/admin/attendance', label: 'Attendance' }
]

export default function AppShell({ children }) {
  const location = useLocation()
  const navigate = useNavigate()
  const role = getRole()
  const links = role === 'HR' ? ADMIN_LINKS : EMPLOYEE_LINKS

  function handleLogout() {
    logout()
    navigate('/signin')
  }

  return (
    <div className="app-shell">
      <header className="app-topbar">
        <div className="app-brand-mark">
          <span className="auth-brand-dot" />
          Dayflow
        </div>

        <nav className="app-nav">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className={location.pathname === l.to ? 'app-nav-link active' : 'app-nav-link'}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="app-topbar-right">
          <span className="app-user-chip">{getEmployeeId()} · {role === 'HR' ? 'HR Officer' : 'Employee'}</span>
          <button className="app-logout-btn" onClick={handleLogout}>Logout</button>
        </div>
      </header>

      <main className="app-content">{children}</main>
    </div>
  )
}
