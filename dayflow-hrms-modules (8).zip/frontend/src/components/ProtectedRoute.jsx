import { Navigate, Outlet } from 'react-router-dom'
import { isLoggedIn, getRole } from '../api/apiClient.js'

/** Blocks access unless signed in; optionally restricts to a role (e.g. "HR"). */
export default function ProtectedRoute({ requireRole }) {
  if (!isLoggedIn()) return <Navigate to="/signin" replace />
  if (requireRole && getRole() !== requireRole) return <Navigate to="/dashboard" replace />
  return <Outlet />
}
