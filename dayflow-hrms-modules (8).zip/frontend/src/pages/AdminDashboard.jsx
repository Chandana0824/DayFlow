import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import AppShell from '../components/AppShell.jsx'
import StatusBadge from '../components/StatusBadge.jsx'
import { getAdminDashboard } from '../api/dashboardApi.js'

export default function AdminDashboard() {
  const navigate = useNavigate()
  const [data, setData] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    getAdminDashboard()
      .then(setData)
      .catch((err) => setError(err.message))
  }, [])

  return (
    <AppShell>
      <div className="page-header">
        <h2>Admin Dashboard</h2>
        <p>Employee overview, attendance snapshot and approvals.</p>
      </div>

      {error && <div className="banner banner-error" style={{ marginBottom: 24 }}>{error}</div>}

      {data && (
        <div className="stat-row">
          <div className="stat-card">
            <div className="stat-value">{data.totalEmployees}</div>
            <div className="stat-label">Total employees</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">{data.presentToday}</div>
            <div className="stat-label">Present today</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">{data.onLeaveToday}</div>
            <div className="stat-label">On leave today</div>
          </div>
          <div className="stat-card">
            <div className="stat-value">{data.pendingLeaveApprovals}</div>
            <div className="stat-label">Pending approvals</div>
          </div>
        </div>
      )}

      <div className="panel">
        <h3>Employees</h3>
        {data && data.employees && data.employees.length > 0 ? (
          <table className="data-table">
            <thead>
              <tr>
                <th>Employee ID</th>
                <th>Name</th>
                <th>Role</th>
                <th>Department</th>
                <th>Today</th>
              </tr>
            </thead>
            <tbody>
              {data.employees.map((e) => (
                <tr
                  key={e.employeeId}
                  className="employee-list-item"
                  onClick={() => navigate(`/admin/attendance?employee=${e.employeeId}`)}
                >
                  <td>{e.employeeId}</td>
                  <td>{e.fullName}</td>
                  <td>{e.role === 'HR' ? 'HR Officer' : 'Employee'}</td>
                  <td>{e.department || '—'}</td>
                  <td><StatusBadge status={e.todayStatus} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p className="empty-state">{data ? 'No employees yet.' : 'Loading…'}</p>
        )}
      </div>
    </AppShell>
  )
}
