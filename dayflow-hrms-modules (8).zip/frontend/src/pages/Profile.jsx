import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import AppShell from '../components/AppShell.jsx'
import FormField from '../components/FormField.jsx'
import {
  getOwnProfile,
  updateOwnProfile,
  getEmployeeProfile,
  updateEmployeeProfileAsAdmin
} from '../api/profileApi.js'
import {
  getMyDocuments,
  getDocumentsForEmployee,
  addDocument,
  deleteDocument
} from '../api/documentsApi.js'
import { getRole } from '../api/apiClient.js'

/**
 * Handles both cases from spec 3.3:
 * - An Employee viewing/editing their own profile (limited fields: phone,
 *   address, profile picture — job details & salary are read-only)
 * - An Admin/HR viewing/editing any employee's profile via ?employee=ID
 *   (full field set including job details and salary structure)
 */
export default function Profile() {
  const [params] = useSearchParams()
  const targetEmployeeId = params.get('employee') // present only when Admin opens someone else's profile
  const role = getRole()
  const isAdminEditingOther = role === 'HR' && targetEmployeeId

  const [profile, setProfile] = useState(null)
  const [form, setForm] = useState({});
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  const [documents, setDocuments] = useState([])
  const [docsLoading, setDocsLoading] = useState(true)
  const [newDocName, setNewDocName] = useState('')
  const [newDocUrl, setNewDocUrl] = useState('')
  const [docBusy, setDocBusy] = useState(false)
  const [docError, setDocError] = useState('')

  function loadDocuments() {
    setDocsLoading(true)
    const loader = isAdminEditingOther ? getDocumentsForEmployee(targetEmployeeId) : getMyDocuments()
    loader
      .then(setDocuments)
      .catch((err) => setDocError(err.message))
      .finally(() => setDocsLoading(false))
  }

  useEffect(() => {
    const loader = isAdminEditingOther ? getEmployeeProfile(targetEmployeeId) : getOwnProfile()
    loader
      .then((p) => {
        setProfile(p)
        setForm({
          fullName: p.fullName || '',
          phone: p.phone || '',
          address: p.address || '',
          profilePictureUrl: p.profilePictureUrl || '',
          designation: p.designation || '',
          department: p.department || '',
          dateOfJoining: p.dateOfJoining || '',
          reportingManager: p.reportingManager || '',
          basicSalary: p.basicSalary ?? '',
          allowances: p.allowances ?? '',
          deductions: p.deductions ?? ''
        })
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false))
  }, [targetEmployeeId])

  useEffect(() => {
    loadDocuments()
  }, [targetEmployeeId])

  async function handleAddDocument(e) {
    e.preventDefault()
    if (!newDocName.trim() || !newDocUrl.trim()) return
    setDocBusy(true)
    setDocError('')
    try {
      await addDocument(targetEmployeeId, { name: newDocName.trim(), url: newDocUrl.trim() })
      setNewDocName('')
      setNewDocUrl('')
      loadDocuments()
    } catch (err) {
      setDocError(err.message)
    } finally {
      setDocBusy(false)
    }
  }

  async function handleDeleteDocument(id) {
    setDocBusy(true)
    setDocError('')
    try {
      await deleteDocument(id)
      loadDocuments()
    } catch (err) {
      setDocError(err.message)
    } finally {
      setDocBusy(false)
    }
  }

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }))
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setSuccess('')
    setSaving(true)
    try {
      let updated
      if (isAdminEditingOther) {
        updated = await updateEmployeeProfileAsAdmin(targetEmployeeId, {
          ...form,
          basicSalary: form.basicSalary === '' ? null : Number(form.basicSalary),
          allowances: form.allowances === '' ? null : Number(form.allowances),
          deductions: form.deductions === '' ? null : Number(form.deductions)
        })
      } else {
        updated = await updateOwnProfile({
          fullName: form.fullName,
          phone: form.phone,
          address: form.address,
          profilePictureUrl: form.profilePictureUrl
        })
      }
      setProfile(updated)
      setSuccess('Profile updated.')
    } catch (err) {
      setError(err.message)
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return <AppShell><p className="empty-state">Loading profile…</p></AppShell>
  }

  return (
    <AppShell>
      <div className="page-header">
        <h2>{isAdminEditingOther ? `Editing ${profile?.fullName || targetEmployeeId}` : 'Your profile'}</h2>
        <p>{isAdminEditingOther ? 'Admin view — all fields editable.' : 'Address, phone and photo are yours to edit. Job and salary details are managed by HR.'}</p>
      </div>

      <div className="profile-header">
        <div className="profile-avatar">
          {profile?.profilePictureUrl
            ? <img src={profile.profilePictureUrl} alt="" />
            : (profile?.fullName || profile?.employeeId || '?').charAt(0).toUpperCase()}
        </div>
        <div>
          <div style={{ fontWeight: 600, fontSize: 'var(--fs-md)' }}>{profile?.fullName || profile?.employeeId}</div>
          <div style={{ color: 'var(--slate)', fontSize: 'var(--fs-sm)' }}>{profile?.email} · {profile?.employeeId}</div>
        </div>
      </div>

      {error && <div className="banner banner-error" style={{ marginBottom: 20 }}>{error}</div>}
      {success && <div className="banner banner-success" style={{ marginBottom: 20 }}>{success}</div>}

      <form onSubmit={handleSubmit}>
        <div className="panel">
          <h3>Personal details</h3>
          <div className="profile-grid">
            <FormField label="Full name" id="fullName">
              <input id="fullName" value={form.fullName} onChange={(e) => update('fullName', e.target.value)} />
            </FormField>
            <FormField label="Phone" id="phone">
              <input id="phone" value={form.phone} onChange={(e) => update('phone', e.target.value)} placeholder="+91 98765 43210" />
            </FormField>
            <FormField label="Address" id="address">
              <input id="address" value={form.address} onChange={(e) => update('address', e.target.value)} />
            </FormField>
            <FormField label="Profile picture URL" id="profilePictureUrl" hint="Paste an image link">
              <input id="profilePictureUrl" value={form.profilePictureUrl} onChange={(e) => update('profilePictureUrl', e.target.value)} />
            </FormField>
          </div>
        </div>

        <div className="panel">
          <h3>Job details</h3>
          {isAdminEditingOther ? (
            <div className="profile-grid">
              <FormField label="Designation" id="designation">
                <input id="designation" value={form.designation} onChange={(e) => update('designation', e.target.value)} />
              </FormField>
              <FormField label="Department" id="department">
                <input id="department" value={form.department} onChange={(e) => update('department', e.target.value)} />
              </FormField>
              <FormField label="Date of joining" id="dateOfJoining">
                <input id="dateOfJoining" type="date" value={form.dateOfJoining} onChange={(e) => update('dateOfJoining', e.target.value)} />
              </FormField>
              <FormField label="Reporting manager" id="reportingManager">
                <input id="reportingManager" value={form.reportingManager} onChange={(e) => update('reportingManager', e.target.value)} />
              </FormField>
            </div>
          ) : (
            <div className="profile-grid">
              <div className="readonly-field"><span className="label">Designation</span><span className="value">{profile?.designation || '—'}</span></div>
              <div className="readonly-field"><span className="label">Department</span><span className="value">{profile?.department || '—'}</span></div>
              <div className="readonly-field"><span className="label">Date of joining</span><span className="value">{profile?.dateOfJoining || '—'}</span></div>
              <div className="readonly-field"><span className="label">Reporting manager</span><span className="value">{profile?.reportingManager || '—'}</span></div>
            </div>
          )}
        </div>

        <div className="panel">
          <h3>Salary structure {!isAdminEditingOther && <span style={{ fontSize: 'var(--fs-xs)', color: 'var(--slate-soft)', fontWeight: 400 }}>(read-only)</span>}</h3>
          {isAdminEditingOther ? (
            <div className="profile-grid">
              <FormField label="Basic salary" id="basicSalary">
                <input id="basicSalary" type="number" value={form.basicSalary} onChange={(e) => update('basicSalary', e.target.value)} />
              </FormField>
              <FormField label="Allowances" id="allowances">
                <input id="allowances" type="number" value={form.allowances} onChange={(e) => update('allowances', e.target.value)} />
              </FormField>
              <FormField label="Deductions" id="deductions">
                <input id="deductions" type="number" value={form.deductions} onChange={(e) => update('deductions', e.target.value)} />
              </FormField>
            </div>
          ) : (
            <div className="profile-grid">
              <div className="readonly-field"><span className="label">Basic</span><span className="value">{profile?.basicSalary ?? '—'}</span></div>
              <div className="readonly-field"><span className="label">Allowances</span><span className="value">{profile?.allowances ?? '—'}</span></div>
              <div className="readonly-field"><span className="label">Deductions</span><span className="value">{profile?.deductions ?? '—'}</span></div>
              <div className="readonly-field"><span className="label">Net salary</span><span className="value">{profile?.netSalary ?? '—'}</span></div>
            </div>
          )}
        </div>

        <button className="btn-primary" type="submit" disabled={saving}>
          {saving ? 'Saving…' : 'Save changes'}
        </button>
      </form>

      <div className="panel">
        <h3>Documents</h3>
        {docError && <div className="banner banner-error" style={{ marginBottom: 16 }}>{docError}</div>}

        {docsLoading ? (
          <p className="empty-state">Loading…</p>
        ) : documents.length === 0 ? (
          <p className="empty-state">No documents on file yet.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Uploaded</th>
                <th></th>
                {isAdminEditingOther && <th></th>}
              </tr>
            </thead>
            <tbody>
              {documents.map((d) => (
                <tr key={d.id}>
                  <td>{d.name}</td>
                  <td>{d.uploadedAt}</td>
                  <td><a href={d.url} target="_blank" rel="noreferrer">View</a></td>
                  {isAdminEditingOther && (
                    <td>
                      <button
                        type="button"
                        className="btn-secondary"
                        onClick={() => handleDeleteDocument(d.id)}
                        disabled={docBusy}
                      >
                        Remove
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {isAdminEditingOther && (
          <form onSubmit={handleAddDocument} style={{ marginTop: 20 }}>
            <div className="profile-grid">
              <FormField label="Document name" id="docName">
                <input
                  id="docName"
                  placeholder="Offer letter"
                  value={newDocName}
                  onChange={(e) => setNewDocName(e.target.value)}
                />
              </FormField>
              <FormField label="Document URL" id="docUrl" hint="Link to the file (e.g. Google Drive)">
                <input
                  id="docUrl"
                  placeholder="https://…"
                  value={newDocUrl}
                  onChange={(e) => setNewDocUrl(e.target.value)}
                />
              </FormField>
            </div>
            <button className="btn-secondary" type="submit" disabled={docBusy} style={{ marginTop: 12 }}>
              {docBusy ? 'Adding…' : 'Add document'}
            </button>
          </form>
        )}
      </div>
    </AppShell>
  )
}
