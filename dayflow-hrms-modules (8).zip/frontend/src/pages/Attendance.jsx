import { useEffect, useState } from 'react'
import AppShell from '../components/AppShell.jsx'
import StatusBadge from '../components/StatusBadge.jsx'
import { checkIn, checkOut, getMyAttendance } from '../api/attendanceApi.js'
import { todayISO, daysAgoISO } from '../utils/dates.js'

/** Employee-facing attendance: check-in/out (3.4.1) + own daily/weekly view (3.4.2). */
export default function Attendance() {
  const [range, setRange] = useState('week') // 'day' | 'week'
  const [records, setRecords] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [actionMsg, setActionMsg] = useState('')
  const [busy, setBusy] = useState(false)

  function load() {
    setLoading(true)
    const from = range === 'day' ? todayISO() : daysAgoISO(7)
    getMyAttendance(from, todayISO())
      .then(setRecords)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [range])

  async function handleCheckIn() {
    setBusy(true); setError(''); setActionMsg('')
    try {
      await checkIn()
      setActionMsg('Checked in successfully.')
      load()
    } catch (err) { setError(err.message) } finally { setBusy(false) }
  }

  async function handleCheckOut() {
    setBusy(true); setError(''); setActionMsg('')
    try {
      await checkOut()
      setActionMsg('Checked out successfully.')
      load()
    } catch (err) { setError(err.message) } finally { setBusy(false) }
  }

  const todayRecord = records.find((r) => r.date === todayISO())

  return (
    <AppShell>
      <div className="page-header">
        <h2>Attendance</h2>
        <p>Check in when your day starts, check out when it ends.</p>
      </div>

      {error && <div className="banner banner-error" style={{ marginBottom: 20 }}>{error}</div>}
      {actionMsg && <div className="banner banner-success" style={{ marginBottom: 20 }}>{actionMsg}</div>}

      <div className="panel">
        <h3>Today</h3>
        <div className="attendance-controls">
          <button className="btn-primary" onClick={handleCheckIn} disabled={busy || Boolean(todayRecord?.checkIn)}>
            {todayRecord?.checkIn ? `Checked in at ${todayRecord.checkIn}` : 'Check in'}
          </button>
          <button className="btn-secondary" onClick={handleCheckOut} disabled={busy || !todayRecord?.checkIn || Boolean(todayRecord?.checkOut)}>
            {todayRecord?.checkOut ? `Checked out at ${todayRecord.checkOut}` : 'Check out'}
          </button>
          {todayRecord && <StatusBadge status={todayRecord.status} />}
        </div>
      </div>

      <div className="panel">
        <div className="date-range-row">
          <h3 style={{ margin: 0 }}>History</h3>
          <div className="role-toggle" style={{ maxWidth: 220 }}>
            <button className={range === 'day' ? 'active' : ''} onClick={() => setRange('day')}>Today</button>
            <button className={range === 'week' ? 'active' : ''} onClick={() => setRange('week')}>Past week</button>
          </div>
        </div>

        {loading ? (
          <p className="empty-state">Loading…</p>
        ) : records.length === 0 ? (
          <p className="empty-state">No attendance records in this range yet.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr><th>Date</th><th>Check-in</th><th>Check-out</th><th>Status</th></tr>
            </thead>
            <tbody>
              {records.map((r) => (
                <tr key={r.id}>
                  <td>{r.date}</td>
                  <td>{r.checkIn || '—'}</td>
                  <td>{r.checkOut || '—'}</td>
                  <td><StatusBadge status={r.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </AppShell>
  )
}
