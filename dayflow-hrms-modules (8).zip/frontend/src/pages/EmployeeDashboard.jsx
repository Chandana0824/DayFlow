import { useEffect, useState } from 'react'
import AppShell from '../components/AppShell.jsx'
import { getEmployeeDashboard } from '../api/dashboardApi.js'

const CARDS = [
  { to: '/profile', icon: 'P', title: 'Profile', desc: 'View and edit your details' },
  { to: '/attendance', icon: 'A', title: 'Attendance', desc: 'Check in, check out, view history' },
  { to: '/leave', icon: 'L', title: 'Leave Requests', desc: 'Apply for time off (coming soon)' },
  { to: '/signin', icon: 'X', title: 'Logout', desc: 'End your session' }
]

export default function EmployeeDashboard() {
  const [data, setData] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    getEmployeeDashboard()
      .then(setData)
      .catch((err) => setError(err.message))
  }, [])

  return (
    <AppShell>
      <div className="page-header">
        <h2>{data ? `Welcome back, ${data.fullName}` : 'Welcome back'}</h2>
        <p>Here's what's happening with your workday.</p>
      </div>

      {error && <div className="banner banner-error" style={{ marginBottom: 24 }}>{error}</div>}

      <div className="quick-cards">
        {CARDS.map((c) => (
          <a key={c.title} href={c.to} className="quick-card">
            <div className="quick-card-icon">{c.icon}</div>
            <h3>{c.title}</h3>
            <p>{c.desc}</p>
          </a>
        ))}
      </div>

      <div className="panel">
        <h3>Today</h3>
        {data ? (
          <p style={{ color: 'var(--slate)', fontSize: 'var(--fs-sm)' }}>
            Status: <strong style={{ color: 'var(--ink)' }}>{data.todayStatus}</strong>
            {data.designation ? <> · {data.designation}</> : null}
          </p>
        ) : (
          <p className="empty-state">Loading…</p>
        )}
      </div>

      <div className="panel">
        <h3>Recent activity</h3>
        {data && data.recentActivity && data.recentActivity.length > 0 ? (
          <ul className="activity-list">
            {data.recentActivity.map((a, i) => <li key={i}>{a}</li>)}
          </ul>
        ) : (
          <p className="empty-state">No attendance recorded yet — check in from the Attendance page to get started.</p>
        )}
      </div>
    </AppShell>
  )
}
