import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Link } from 'react-router-dom'
import AppShell from '../components/AppShell.jsx'
import StatusBadge from '../components/StatusBadge.jsx'
import { getAllAttendance, getAttendanceForEmployee } from '../api/attendanceApi.js'
import { todayISO, daysAgoISO } from '../utils/dates.js'

/** Admin/HR: attendance across all employees, or filtered to one via ?employee= (3.4.2). */
export default function AdminAttendance() {
  const [params, setParams] = useSearchParams()
  const employeeFilter = params.get('employee') || ''
  const [range, setRange] = useState('week')
  const [records, setRecords] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    setLoading(true)
    const from = range === 'day' ? todayISO() : daysAgoISO(7)
    const loader = employeeFilter
      ? getAttendanceForEmployee(employeeFilter, from, todayISO())
      : getAllAttendance(from, todayISO())

    loader
      .then(setRecords)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false))
  }, [range, employeeFilter])

  return (
    <AppShell>
      <div className="page-header">
        <h2>Attendance records</h2>
        <p>{employeeFilter ? `Showing attendance for ${employeeFilter}.` : 'Showing attendance for all employees.'}</p>
      </div>

      {error && <div className="banner banner-error" style={{ marginBottom: 20 }}>{error}</div>}

      <div className="panel">
        <div className="date-range-row">
          <div className="role-toggle" style={{ maxWidth: 220 }}>
            <button className={range === 'day' ? 'active' : ''} onClick={() => setRange('day')}>Today</button>
            <button className={range === 'week' ? 'active' : ''} onClick={() => setRange('week')}>Past week</button>
          </div>
          {employeeFilter && (
            <>
              <Link className="btn-secondary" to={`/profile?employee=${employeeFilter}`}>Edit profile</Link>
              <button className="btn-secondary" onClick={() => setParams({})}>Clear employee filter</button>
            </>
          )}
        </div>

        {loading ? (
          <p className="empty-state">Loading…</p>
        ) : records.length === 0 ? (
          <p className="empty-state">No attendance records in this range.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr><th>Employee ID</th><th>Date</th><th>Check-in</th><th>Check-out</th><th>Status</th></tr>
            </thead>
            <tbody>
              {records.map((r) => (
                <tr key={r.id}>
                  <td>{r.employeeId}</td>
                  <td>{r.date}</td>
                  <td>{r.checkIn || '—'}</td>
                  <td>{r.checkOut || '—'}</td>
                  <td><StatusBadge status={r.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </AppShell>
  )
}
