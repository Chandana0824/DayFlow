export function toISODate(d) {
  return d.toISOString().slice(0, 10)
}

export function todayISO() {
  return toISODate(new Date())
}

export function daysAgoISO(n) {
  const d = new Date()
  d.setDate(d.getDate() - n)
  return toISODate(d)
}
