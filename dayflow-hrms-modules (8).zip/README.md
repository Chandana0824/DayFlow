# Dayflow HRMS — Auth, Dashboard, Profile & Attendance

A complete, working implementation of sections **3.1–3.4** of the Dayflow
HRMS requirements doc:

- **3.1** Authentication & Authorization (Sign Up / Sign In / email verification)
- **3.2** Dashboards (Employee quick-access cards, Admin/HR employee overview)
- **3.3** Employee Profile Management (view + edit, employee-limited vs admin-full)
- **3.4** Attendance Management (check-in/check-out, daily/weekly views, admin-wide view)

Stack: **React (Vite) + Java (Spring Boot) + SQLite**, exactly as scoped.

```
dayflow-auth/
├── backend/     Spring Boot API (Java 17, SQLite, JWT, BCrypt)
└── frontend/    React (Vite) — Sign Up / Sign In / Verify Email
```

## What's implemented

### 3.1 Authentication & Authorization
- Sign up with Employee ID, email, password, role (Employee / HR)
- Password rule enforcement: 8+ chars, upper+lower+number+symbol — enforced
  on both the client (instant feedback) and the server (source of truth)
- Duplicate email / Employee ID rejected with a clear error
- Email verification via a signed token link, only relevant if you sign up
  a new account. **For the demo, you don't need it at all** — see below.
- Two pre-verified accounts are seeded automatically on backend startup
  (`config/DataSeeder.java`), so you can sign in immediately with no
  sign-up/verification step:

  | Role | Email | Password |
  |---|---|---|
  | Employee | `employee@dayflow.test` | `Employee@123` |
  | HR / Admin | `hr@dayflow.test` | `HrAdmin@123` |

  Want real Gmail verification for new sign-ups instead? Set
  `app.mail.enabled=true` and fill in `spring.mail.username` /
  `spring.mail.password` with a Gmail address + an
  [App Password](https://myaccount.google.com/apppasswords) (needs 2-Step
  Verification turned on first).
- Sign in with email + password, JWT issued on success
- Incorrect credentials → clear error message, no user enumeration
- Passwords hashed with BCrypt, never stored or logged in plain text
- All protected endpoints below now require that JWT via an `Authorization: Bearer` header,
  checked by `JwtAuthFilter` on the backend

### 3.2 Dashboards
- **Employee**: quick-access cards (Profile, Attendance, Leave Requests, Logout),
  today's status, and recent attendance activity — `GET /api/dashboard/employee`
- **Admin/HR**: employee count, present/on-leave-today counts, full employee
  list with today's status per person, click a row to jump into their
  attendance or profile — `GET /api/dashboard/admin` (HR-only)

### 3.3 Employee Profile Management
- **View** (3.3.1): personal details, job details, salary structure, and
  **documents** — `GET /api/profile/me` (own) or `GET /api/profile/{employeeId}`
  (HR, any employee); documents separately via `GET /api/documents/me` or
  `GET /api/documents/{employeeId}`
- **Edit** (3.3.2): employees can edit name, phone, address, profile picture
  only (`PUT /api/profile/me`); HR can edit everything including job details
  and salary (`PUT /api/profile/{employeeId}`) — enforced server-side via
  two separate DTOs, not just hidden in the UI
- **Documents**: HR can attach/remove documents on any employee's profile
  (`POST` / `DELETE /api/documents/{employeeId}`) as links (e.g. a Google
  Drive URL) rather than binary file storage, to keep the hackathon scope
  realistic; employees see a read-only list on their own profile
- Net salary is computed server-side (basic + allowances − deductions)

### 3.4 Attendance Management
- **Check-in / check-out** (3.4.1): `POST /api/attendance/check-in` and
  `/check-out`; a session under 4 hours is auto-marked Half-day, otherwise Present
- Status types: Present, Absent, Half-day, Leave
- **Views** (3.4.2): employees see only their own attendance
  (`GET /api/attendance/me?from=&to=`) with a Today/Past-week toggle;
  HR sees everyone's (`GET /api/attendance?from=&to=`) or one employee's
  (`GET /api/attendance/{employeeId}?from=&to=`)

Real backend calls throughout — no static JSON, per the hackathon "must-have" list.

## Running it locally

### 1. Backend (Spring Boot + SQLite)
```bash
cd backend
./mvnw spring-boot:run
```
Runs on `http://localhost:8080`. A `dayflow.db` SQLite file is created
automatically on first run — nothing to install.

### 2. Frontend (React + Vite)
```bash
cd frontend
npm install
npm run dev
```
Runs on `http://localhost:5173` and proxies `/api/*` to the backend
(see `vite.config.js`), so there's no CORS setup needed in dev.

Open `http://localhost:5173/signup`, create an account, check the backend
console for the verification link (dev mode), then sign in.

## ⚠️ Before you push: don't leak your Gmail app password

`application.properties` now has a real `spring.mail.password` in it once
you fill it in. If your GitHub repo is public (common for hackathons),
**do not commit it as-is**. Pick one:

- **Easiest**: after testing locally, put the placeholder text back
  (`YOUR_16_CHAR_APP_PASSWORD`) before you `git add` / commit / push.
- **Better**: leave the placeholders in the file, and instead run the
  backend with environment variables that override them:
  ```bash
  # macOS/Linux
  export SPRING_MAIL_USERNAME=you@gmail.com
  export SPRING_MAIL_PASSWORD=your16charapppassword
  ./mvnw spring-boot:run
  ```
  ```powershell
  # Windows PowerShell
  $env:SPRING_MAIL_USERNAME="you@gmail.com"
  $env:SPRING_MAIL_PASSWORD="your16charapppassword"
  mvn spring-boot:run
  ```
  Spring Boot automatically maps `SPRING_MAIL_USERNAME` /
  `SPRING_MAIL_PASSWORD` to `spring.mail.username` / `spring.mail.password`,
  so the file itself never has to hold the real value.

If you ever do commit a real app password by accident, go back to
Google Account → Security → App Passwords and revoke it, then generate
a new one — don't just remove it from a later commit, since it's still
visible in git history.

## Pushing this into your team repo properly

Since the doc says *"one member managing the repo is not enough"*, here's a
clean way to bring this in without one person owning everything:

```bash
# from inside your existing DayFlow repo
git checkout -b feature/auth-module
mkdir -p backend frontend
# copy the contents of backend/ and frontend/ from this folder into your repo
git add backend frontend
git commit -m "Add authentication module (sign up, sign in, email verification)"
git push origin feature/auth-module
# then open a PR into main so teammates can review before merging
```

Each teammate should work on their own module on its own branch
(`feature/attendance`, `feature/leave`, `feature/payroll`, etc.) and open a
PR — that's what satisfies "use version control properly" as a team, not
just having multiple collaborators on the repo.

## Design notes

The UI follows one idea end to end: the product is literally named
"Dayflow," so the auth screens use a gradient that moves from indigo
("morning") to amber ("afternoon") — most visibly in the animated day
timeline on the left panel, labeled with the actual milestones this HRMS
tracks (check-in → tasks → leave → check-out). Typeface pairing is
Fraunces (display) + Inter (body) + IBM Plex Mono (labels/data), which
keeps it feeling like a considered internal tool rather than a generic
admin template.

## What's left (3.5 Leave, 3.6 Payroll analytics)

Everything up through Attendance (3.1–3.4) is done and wired together. Still open per the spec:
- **3.5 Leave & Time-Off**: apply for leave, approve/reject as HR — the
  Employee Dashboard already has a "Leave Requests" card pointing at `/leave`
  and pending-leave counts stubbed at `0` in `DashboardService`, ready for
  a teammate to wire a real `LeaveService` into
- **3.6 Payroll**: salary fields already exist on the profile (`basicSalary`,
  `allowances`, `deductions`, computed `netSalary`) — a payroll module can
  read/extend these directly instead of duplicating them
- Analytics & reports dashboard (salary slips, attendance reports)

## Integration points for teammates

- `localStorage.dayflow_token` holds the JWT after sign-in — send it as a
  `Bearer` token on any new protected API call (see `frontend/src/api/apiClient.js`)
- `localStorage.dayflow_role` (`EMPLOYEE` / `HR`) — used to branch dashboard
  UI and gate HR-only screens (see `components/ProtectedRoute.jsx`)
- Backend: `JwtAuthFilter` + `SecurityConfig` already protect everything
  except `/api/auth/**` — a new controller just needs `@PreAuthorize("hasRole('HR')")`
  on admin-only endpoints, same pattern as `AttendanceController`
